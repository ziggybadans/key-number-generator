Thank you for downloading!

To install, run the setup.exe file. There may be a Windows Defender prompt since it is an exe, but just click 'More info' and then 'Run Anyway'.
If you don't feel comfortable with installing it directly, a ZIP version is available on the GitHub.
The setup file requires an internet connection to run.

The setup program will download and install the program, and run it afterwards. The program will be located in your start menu.
Updates will automatically install through the program every time it launches, and will give a prompt if you'd like to update.

To uninstall the program, simply right-click the program in the start menu and select uninstall.
It will take you to control panel, so look for the program 'KeyNumberGenerator' and click uninstall and follow any prompts.